# Flights dataset exploration
## by michael Reda Adly Wassef


## Dataset

> This is a dataset of the flights in December 2008.


## Summary of Findings

> We studied the flights in December. We found that more flights in December are before the Christmas season. Moreover, most of the flights are on Friday before the weekend. Furthermore, we studied the flights delay. Almost, 25% of the flights are delayed in December. Most of the delays are becuase of NAS (delay that is within the control of the National Airspace System) and carrier delays.

## Key insights

> In the presentation, first the flights frequency in December is explored. Then, we explore more the delays of the flights and what are the main reasons for the delays.